"""Détection du type de contenu et application des filtres configurés."""

from __future__ import annotations

from typing import Any


CONTENT_TYPES = ("video", "photo", "document", "audio", "gif", "text", "file")
DEFAULT_TYPES = set(CONTENT_TYPES)


def detect_content_type(message: Any) -> str:
    if getattr(message, "gif", None):
        return "gif"
    if getattr(message, "video", None):
        return "video"
    if getattr(message, "photo", None):
        return "photo"
    if getattr(message, "audio", None):
        return "audio"
    if getattr(message, "document", None):
        return "document"
    if getattr(message, "media", None):
        return "file"
    return "text"


def enabled_content_types(get_setting: Any) -> set[str]:
    raw = get_setting("content_types")
    if not raw:
        return set(DEFAULT_TYPES)
    configured = {item.strip().lower() for item in raw.split(",") if item.strip()}
    return configured & set(CONTENT_TYPES) or set(DEFAULT_TYPES)


def configured_keywords(get_setting: Any) -> list[str]:
    raw = get_setting("keywords", "") or ""
    return [item.strip().casefold() for item in raw.replace("\n", ",").split(",") if item.strip()]


def matches_filters(message: Any, get_setting: Any) -> bool:
    content_type = detect_content_type(message)
    if content_type not in enabled_content_types(get_setting):
        return False

    keywords = configured_keywords(get_setting)
    if not keywords:
        return True

    text = (getattr(message, "raw_text", None) or "").casefold()
    return any(keyword in text for keyword in keywords)