"""Chargement de la configuration depuis les variables d'environnement."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv


PROJECT_DIR = Path(__file__).resolve().parents[1]
load_dotenv(PROJECT_DIR / ".env")


def _required(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(
            f"La variable {name} est absente. Copiez .env.example vers .env et renseignez-la."
        )
    return value


def _to_bool(value: str, default: bool) -> bool:
    if not value:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on", "oui"}


@dataclass(frozen=True)
class Settings:
    api_id: int
    api_hash: str
    bot_token: str
    admin_id: int
    database_path: Path
    log_path: Path
    session_path: str
    autostart: bool


def load_settings() -> Settings:
    try:
        api_id = int(_required("API_ID"))
        admin_id = int(_required("ADMIN_ID"))
    except ValueError as exc:
        raise RuntimeError("API_ID et ADMIN_ID doivent être des nombres entiers.") from exc

    data_dir = PROJECT_DIR / "data"
    log_path = PROJECT_DIR / "logs" / "bot.log"
    data_dir.mkdir(parents=True, exist_ok=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    return Settings(
        api_id=api_id,
        api_hash=_required("API_HASH"),
        bot_token=_required("BOT_TOKEN"),
        admin_id=admin_id,
        database_path=data_dir / "republisher.sqlite3",
        log_path=log_path,
        session_path=str(data_dir / "user_session"),
        autostart=_to_bool(os.getenv("AUTOSTART", "true"), True),
    )