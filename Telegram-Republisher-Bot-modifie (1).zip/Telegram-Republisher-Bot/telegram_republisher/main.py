"""Point d'entrée du bot de republication Telegram."""

from __future__ import annotations

import asyncio
import logging

from config.settings import load_settings
from database.database import Database
from telegram.bot_handlers import BotHandlers
from telegram.client import build_clients
from telegram.monitor import Monitor, RuntimeState
from telegram.publisher import Publisher
from utils.logger import configure_logging


async def run() -> None:
    settings = load_settings()
    configure_logging(settings.log_path)
    logger = logging.getLogger(__name__)

    database = Database(settings.database_path)
    database.initialize()

    user_client, bot_client = build_clients(settings)
    state = RuntimeState(running=settings.autostart and bool(database.get_destination()))
    publisher = Publisher(user_client, database, state, logger)
    monitor = Monitor(user_client, publisher)
    handlers = BotHandlers(bot_client, user_client, database, state, settings.admin_id)

    try:
        logger.info("Connexion du compte Telegram utilisé pour la lecture des sources")
        await user_client.start()
        await bot_client.start(bot_token=settings.bot_token)
        monitor.register()
        handlers.register()

        print("🤖 Republisher démarré")
        print(f"📥 Sources : {len(database.list_sources())}")
        print(f"📤 Destination : {database.get_destination() or 'non définie'}")
        print(f"{'🟢 Surveillance active' if state.running else '⏸️ Surveillance en pause'}")
        logger.info(
            "Republisher démarré: sources=%s destination=%s running=%s",
            len(database.list_sources()),
            database.get_destination() or "non définie",
            state.running,
        )

        await bot_client.run_until_disconnected()
    finally:
        monitor.unregister()
        handlers.unregister()
        if bot_client.is_connected():
            await bot_client.disconnect()
        if user_client.is_connected():
            await user_client.disconnect()
        database.close()


def main() -> None:
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        print("\nArrêt demandé.")


if __name__ == "__main__":
    main()