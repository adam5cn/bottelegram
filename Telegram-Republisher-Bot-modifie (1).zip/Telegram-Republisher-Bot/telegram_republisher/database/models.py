"""Modèles simples utilisés par la couche SQLite."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass(frozen=True)
class SourceChannel:
    id: int
    chat_id: int
    username: str | None
    title: str
    enabled: bool


@dataclass(frozen=True)
class BroadcastChannel:
    id: int
    chat_id: int
    username: str | None
    title: str
    enabled: bool


@dataclass(frozen=True)
class Publication:
    id: int
    source_chat_id: int
    source_message_id: int
    grouped_id: int | None
    destination_message_id: int | None
    content_type: str
    status: str
    source_name: str
    error_message: str | None
    date: datetime