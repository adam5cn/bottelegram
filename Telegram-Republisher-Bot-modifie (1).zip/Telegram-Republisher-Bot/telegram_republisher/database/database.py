"""Base SQLite de configuration, anti-doublon, statistiques et historique."""

from __future__ import annotations

import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from database.models import BroadcastChannel, Publication, SourceChannel


class Database:
    def __init__(self, path: Path) -> None:
        self.path = path
        self._connection: sqlite3.Connection | None = None
        self._lock = threading.RLock()

    @property
    def connection(self) -> sqlite3.Connection:
        if self._connection is None:
            raise RuntimeError("La base SQLite n'est pas initialisée.")
        return self._connection

    def initialize(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._lock:
            self._connection = sqlite3.connect(
                self.path,
                check_same_thread=False,
                timeout=30,
            )
            self._connection.row_factory = sqlite3.Row
            self._connection.execute("PRAGMA journal_mode=WAL")
            self._connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS source_channels (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    chat_id INTEGER NOT NULL UNIQUE,
                    username TEXT,
                    title TEXT NOT NULL,
                    enabled INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS broadcast_channels (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    chat_id INTEGER NOT NULL UNIQUE,
                    username TEXT,
                    title TEXT NOT NULL,
                    enabled INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS publications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_chat_id INTEGER NOT NULL,
                    source_message_id INTEGER NOT NULL,
                    grouped_id INTEGER,
                    destination_message_id INTEGER,
                    content_type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    source_name TEXT NOT NULL,
                    error_message TEXT,
                    date TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    UNIQUE(source_chat_id, source_message_id)
                );

                CREATE INDEX IF NOT EXISTS idx_publications_status
                    ON publications(status);
                CREATE INDEX IF NOT EXISTS idx_publications_date
                    ON publications(date);
                """
            )
            self.connection.commit()

    def close(self) -> None:
        with self._lock:
            if self._connection is not None:
                self._connection.close()
                self._connection = None

    def get_setting(self, key: str, default: str | None = None) -> str | None:
        with self._lock:
            row = self.connection.execute(
                "SELECT value FROM settings WHERE key = ?",
                (key,),
            ).fetchone()
        return str(row["value"]) if row else default

    def set_setting(self, key: str, value: str) -> None:
        with self._lock:
            self.connection.execute(
                """
                INSERT INTO settings(key, value) VALUES (?, ?)
                ON CONFLICT(key) DO UPDATE SET value = excluded.value
                """,
                (key, value),
            )
            self.connection.commit()

    def get_destination(self) -> str | None:
        return self.get_setting("destination")

    def add_source(self, chat_id: int, username: str | None, title: str) -> None:
        with self._lock:
            self.connection.execute(
                """
                INSERT INTO source_channels(chat_id, username, title, enabled, created_at)
                VALUES (?, ?, ?, 1, ?)
                ON CONFLICT(chat_id) DO UPDATE SET
                    username = excluded.username,
                    title = excluded.title,
                    enabled = 1
                """,
                (chat_id, username, title, _now()),
            )
            self.connection.commit()

    def remove_source(self, source_id: int) -> None:
        with self._lock:
            self.connection.execute("DELETE FROM source_channels WHERE id = ?", (source_id,))
            self.connection.commit()

    def list_sources(self) -> list[SourceChannel]:
        with self._lock:
            rows = self.connection.execute(
                """
                SELECT id, chat_id, username, title, enabled
                FROM source_channels
                WHERE enabled = 1
                ORDER BY id
                """
            ).fetchall()
        return [
            SourceChannel(
                id=int(row["id"]),
                chat_id=int(row["chat_id"]),
                username=row["username"],
                title=str(row["title"]),
                enabled=bool(row["enabled"]),
            )
            for row in rows
        ]

    def get_source_by_chat_id(self, chat_id: int) -> SourceChannel | None:
        with self._lock:
            row = self.connection.execute(
                """
                SELECT id, chat_id, username, title, enabled
                FROM source_channels
                WHERE chat_id = ? AND enabled = 1
                """,
                (chat_id,),
            ).fetchone()
        if row is None:
            return None
        return SourceChannel(
            id=int(row["id"]),
            chat_id=int(row["chat_id"]),
            username=row["username"],
            title=str(row["title"]),
            enabled=bool(row["enabled"]),
        )

    # -- Canaux de diffusion (mode admin) --------------------------------

    def add_broadcast_channel(self, chat_id: int, username: str | None, title: str) -> None:
        with self._lock:
            self.connection.execute(
                """
                INSERT INTO broadcast_channels(chat_id, username, title, enabled, created_at)
                VALUES (?, ?, ?, 1, ?)
                ON CONFLICT(chat_id) DO UPDATE SET
                    username = excluded.username,
                    title = excluded.title
                """,
                (chat_id, username, title, _now()),
            )
            self.connection.commit()

    def remove_broadcast_channel(self, chat_id: int) -> None:
        with self._lock:
            self.connection.execute(
                "DELETE FROM broadcast_channels WHERE chat_id = ?",
                (chat_id,),
            )
            self.connection.commit()

    def set_broadcast_channel_enabled(self, chat_id: int, enabled: bool) -> None:
        with self._lock:
            self.connection.execute(
                "UPDATE broadcast_channels SET enabled = ? WHERE chat_id = ?",
                (1 if enabled else 0, chat_id),
            )
            self.connection.commit()

    def list_broadcast_channels(self, enabled_only: bool = False) -> list[BroadcastChannel]:
        query = "SELECT id, chat_id, username, title, enabled FROM broadcast_channels"
        if enabled_only:
            query += " WHERE enabled = 1"
        query += " ORDER BY id"
        with self._lock:
            rows = self.connection.execute(query).fetchall()
        return [
            BroadcastChannel(
                id=int(row["id"]),
                chat_id=int(row["chat_id"]),
                username=row["username"],
                title=str(row["title"]),
                enabled=bool(row["enabled"]),
            )
            for row in rows
        ]

    def get_broadcast_channel(self, chat_id: int) -> BroadcastChannel | None:
        with self._lock:
            row = self.connection.execute(
                "SELECT id, chat_id, username, title, enabled FROM broadcast_channels WHERE chat_id = ?",
                (chat_id,),
            ).fetchone()
        if row is None:
            return None
        return BroadcastChannel(
            id=int(row["id"]),
            chat_id=int(row["chat_id"]),
            username=row["username"],
            title=str(row["title"]),
            enabled=bool(row["enabled"]),
        )

    def is_processed(self, source_chat_id: int, source_message_id: int) -> bool:
        with self._lock:
            row = self.connection.execute(
                """
                SELECT 1 FROM publications
                WHERE source_chat_id = ? AND source_message_id = ?
                """,
                (source_chat_id, source_message_id),
            ).fetchone()
        return row is not None

    def record_publication(
        self,
        *,
        source_chat_id: int,
        source_message_id: int,
        grouped_id: int | None,
        destination_message_id: int | None,
        content_type: str,
        status: str,
        source_name: str,
        date: datetime | None,
        error_message: str | None = None,
    ) -> None:
        message_date = date or datetime.now(timezone.utc)
        with self._lock:
            self.connection.execute(
                """
                INSERT OR IGNORE INTO publications(
                    source_chat_id, source_message_id, grouped_id,
                    destination_message_id, content_type, status,
                    source_name, error_message, date, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    source_chat_id,
                    source_message_id,
                    grouped_id,
                    destination_message_id,
                    content_type,
                    status,
                    source_name,
                    error_message,
                    message_date.isoformat(),
                    _now(),
                ),
            )
            self.connection.commit()

    def statistics(self) -> dict[str, Any]:
        with self._lock:
            total = self.connection.execute(
                "SELECT COUNT(*) AS count FROM publications WHERE status = 'success'"
            ).fetchone()["count"]
            by_type = self.connection.execute(
                """
                SELECT content_type, COUNT(*) AS count
                FROM publications
                WHERE status = 'success'
                GROUP BY content_type
                """
            ).fetchall()
            errors = self.connection.execute(
                "SELECT COUNT(*) AS count FROM publications WHERE status = 'error'"
            ).fetchone()["count"]
            today = self.connection.execute(
                """
                SELECT COUNT(*) AS count FROM publications
                WHERE status = 'success'
                  AND date >= datetime('now', 'start of day')
                """
            ).fetchone()["count"]
            week = self.connection.execute(
                """
                SELECT COUNT(*) AS count FROM publications
                WHERE status = 'success'
                  AND date >= datetime('now', '-7 days')
                """
            ).fetchone()["count"]
        return {
            "total": int(total),
            "types": {str(row["content_type"]): int(row["count"]) for row in by_type},
            "errors": int(errors),
            "today": int(today),
            "week": int(week),
        }

    def recent_publications(self, limit: int = 10) -> list[Publication]:
        safe_limit = max(1, min(limit, 50))
        with self._lock:
            rows = self.connection.execute(
                f"""
                SELECT id, source_chat_id, source_message_id, grouped_id,
                       destination_message_id, content_type, status,
                       source_name, error_message, date
                FROM publications
                ORDER BY id DESC
                LIMIT {safe_limit}
                """
            ).fetchall()
        return [
            Publication(
                id=int(row["id"]),
                source_chat_id=int(row["source_chat_id"]),
                source_message_id=int(row["source_message_id"]),
                grouped_id=row["grouped_id"],
                destination_message_id=row["destination_message_id"],
                content_type=str(row["content_type"]),
                status=str(row["status"]),
                source_name=str(row["source_name"]),
                error_message=row["error_message"],
                date=datetime.fromisoformat(str(row["date"])),
            )
            for row in rows
        ]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()