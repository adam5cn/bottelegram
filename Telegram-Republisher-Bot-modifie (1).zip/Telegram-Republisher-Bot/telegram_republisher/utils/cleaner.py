"""Nettoyage des mentions et liens Telegram avant publication."""

from __future__ import annotations

import re


MENTION_PATTERN = re.compile(r"(?<!\w)@[A-Za-z0-9_]{3,}")
TELEGRAM_LINK_PATTERN = re.compile(
    r"https?://t\.me/(?:c/)?[A-Za-z0-9_+./?=&%-]+",
    flags=re.IGNORECASE,
)


def clean_text(
    text: str,
    destination: str,
    cleaning_enabled: bool,
    add_destination_enabled: bool,
) -> str:
    cleaned = text or ""
    if cleaning_enabled:
        cleaned = TELEGRAM_LINK_PATTERN.sub("", cleaned)
        cleaned = MENTION_PATTERN.sub("", cleaned)
        cleaned = re.sub(r"[ \t]{2,}", " ", cleaned)
        cleaned = re.sub(r"\n[ \t]*\n[ \t]*\n+", "\n\n", cleaned)
        cleaned = cleaned.strip()

    if add_destination_enabled and destination:
        target = destination if destination.startswith("@") else f"@{destination}"
        if target.casefold() not in cleaned.casefold():
            cleaned = f"{cleaned}\n\n📲 {target}".strip()
    return cleaned