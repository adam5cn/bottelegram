"""Lecture des sources et republication sans en-tête de transfert."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

from database.database import Database
from filters.content_filter import detect_content_type, matches_filters
from telegram.monitor import RuntimeState
from utils.cleaner import clean_text


class Publisher:
    def __init__(
        self,
        user_client: Any,
        database: Database,
        state: RuntimeState,
        logger: logging.Logger,
    ) -> None:
        self.user_client = user_client
        self.database = database
        self.state = state
        self.logger = logger
        self._publish_lock = asyncio.Lock()

    async def handle_new_message(self, event: Any) -> None:
        if not self.state.running or getattr(event, "message", None) is None:
            return

        message = event.message

        if getattr(message, "grouped_id", None):
            return

        await self._publish_messages(event.chat_id, [message])

    async def handle_album(self, event: Any) -> None:
        if not self.state.running:
            return

        messages = list(getattr(event, "messages", []) or [])

        if messages:
            await self._publish_messages(event.chat_id, messages)

    async def _publish_messages(
        self,
        source_chat_id: int,
        messages: list[Any],
    ) -> None:
        async with self._publish_lock:
            await self._publish_messages_locked(
                source_chat_id,
                messages,
            )

    async def _publish_messages_locked(
        self,
        source_chat_id: int,
        messages: list[Any],
    ) -> None:
        source = self.database.get_source_by_chat_id(source_chat_id)

        if source is None:
            return

        destination = self.database.get_destination()

        # Formatage automatique : ajoute '@' s'il s'agit d'un nom d'utilisateur (str) sans '@' au début
        if (
            isinstance(destination, str)
            and not destination.startswith("@")
            and not destination.lstrip("-").isdigit()
        ):
            destination = f"@{destination}"

        source_name = (
            source.username
            or source.title
            or str(source_chat_id)
        )

        # Cibles de diffusion : la destination principale + les canaux du
        # "mode admin" (canaux où le compte est administrateur) activés.
        targets = self._build_targets(destination)

        if not targets:
            self._record_error(
                messages,
                source_chat_id,
                source_name,
                "Aucune destination définie (ni destination principale, ni mode admin).",
            )
            return

        # Évite de republier les messages déjà traités.
        new_messages = [
            message
            for message in messages
            if not self.database.is_processed(
                source_chat_id,
                int(message.id),
            )
        ]

        if not new_messages:
            return

        # Application des filtres existants.
        eligible: list[Any] = []

        for message in new_messages:
            if matches_filters(
                message,
                self.database.get_setting,
            ):
                eligible.append(message)
            else:
                self.database.record_publication(
                    source_chat_id=source_chat_id,
                    source_message_id=int(message.id),
                    grouped_id=getattr(
                        message,
                        "grouped_id",
                        None,
                    ),
                    destination_message_id=None,
                    content_type=detect_content_type(message),
                    status="filtered",
                    source_name=source_name,
                    date=getattr(message, "date", None),
                )

        if not eligible:
            return

        cleaning_enabled = self.database.get_setting("cleaning", "on") == "on"
        add_destination_enabled = self.database.get_setting("add_destination", "on") == "on"

        # Chaque message est envoyé comme un nouveau message, vers
        # chaque cible (destination principale + canaux du mode admin).
        #
        # IMPORTANT :
        # - aucun forward_message()
        # - aucun download_media()
        # - aucun fichier temporaire
        # - le média Telegram est réutilisé directement
        for message in eligible:
            original_text = message.text or ""

            if not getattr(message, "media", None) and not original_text:
                self.database.record_publication(
                    source_chat_id=source_chat_id,
                    source_message_id=int(message.id),
                    grouped_id=getattr(message, "grouped_id", None),
                    destination_message_id=None,
                    content_type=detect_content_type(message),
                    status="filtered",
                    source_name=source_name,
                    date=getattr(message, "date", None),
                )
                continue

            first_sent_id: int | None = None
            last_error: str | None = None
            current_message = message

            for target in targets:
                # Le texte/légende est nettoyé (mentions, liens) et le
                # @username de CHAQUE cible est ajouté si activé, pour
                # que la publication porte bien le nom de la destination
                # (et non plus rien, comme avant).
                target_username = target if isinstance(target, str) else ""
                target_text = clean_text(
                    original_text,
                    target_username,
                    cleaning_enabled,
                    add_destination_enabled,
                )

                try:
                    sent = await self._send_to_target(target, current_message, target_text)
                except Exception as exc:
                    # Les vidéos (fichiers volumineux) sont plus exposées aux
                    # erreurs de "file reference" expirée côté Telegram : on
                    # relit le message source pour obtenir un média frais,
                    # puis on retente une fois avant d'abandonner.
                    self.logger.warning(
                        "Échec d'envoi vers %s pour le message %s de %s (%s) — "
                        "nouvelle tentative après rafraîchissement.",
                        target,
                        message.id,
                        source_name,
                        exc,
                    )
                    try:
                        refreshed = await self.user_client.get_messages(
                            source_chat_id, ids=message.id
                        )
                        if refreshed is not None:
                            current_message = refreshed
                        sent = await self._send_to_target(
                            target, current_message, target_text
                        )
                    except Exception as retry_exc:
                        last_error = str(retry_exc)[:500]
                        self.logger.error(
                            "Échec définitif d'envoi vers %s pour le message %s de %s : %s",
                            target,
                            message.id,
                            source_name,
                            retry_exc,
                        )
                        continue

                sent_id = self._destination_id(sent)
                if first_sent_id is None and sent_id is not None:
                    first_sent_id = sent_id

            self.database.record_publication(
                source_chat_id=source_chat_id,
                source_message_id=int(message.id),
                grouped_id=getattr(message, "grouped_id", None),
                destination_message_id=first_sent_id,
                content_type=detect_content_type(message),
                status="success" if first_sent_id is not None else "error",
                source_name=source_name,
                date=getattr(message, "date", None),
                error_message=last_error if first_sent_id is None else None,
            )

        self.logger.info(
            "Publication traitée: source=%s messages=%s cibles=%s",
            source_name,
            len(eligible),
            targets,
        )

    async def _send_to_target(self, target: str | int, message: Any, text: str) -> Any:
        if getattr(message, "media", None):
            return await self.user_client.send_file(
                target,
                message.media,
                caption=text,
            )
        return await self.user_client.send_message(target, text)

    def _build_targets(self, destination: str | None) -> list[str | int]:
        """Construit la liste des cibles de diffusion.

        Inclut la destination principale (si définie) et tous les canaux
        du "mode admin" activés (canaux où le compte est administrateur).
        """
        targets: list[str | int] = []
        if destination:
            targets.append(destination)

        for channel in self.database.list_broadcast_channels(enabled_only=True):
            entity = f"@{channel.username}" if channel.username else channel.chat_id
            if entity not in targets:
                targets.append(entity)

        return targets

    @staticmethod
    def _destination_id(sent: Any) -> int | None:
        if isinstance(sent, list):
            return (
                int(sent[0].id)
                if sent
                else None
            )

        return (
            int(sent.id)
            if sent is not None
            and getattr(sent, "id", None)
            else None
        )

    def _record_error(
        self,
        messages: list[Any],
        source_chat_id: int,
        source_name: str,
        error_message: str,
    ) -> None:
        for message in messages:
            self.database.record_publication(
                source_chat_id=source_chat_id,
                source_message_id=int(message.id),
                grouped_id=getattr(
                    message,
                    "grouped_id",
                    None,
                ),
                destination_message_id=None,
                content_type=detect_content_type(message),
                status="error",
                source_name=source_name,
                date=getattr(message, "date", None),
                error_message=error_message,
            )