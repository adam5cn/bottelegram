"""Interface de configuration administrateur dans Telegram."""

from __future__ import annotations

from datetime import timezone
import re
from typing import Any

from telethon import events, utils
from telethon.errors import MessageNotModifiedError
from telethon.tl.custom import Button

from database.database import Database
from filters.content_filter import CONTENT_TYPES, enabled_content_types
from telegram.monitor import RuntimeState


class BotHandlers:
    def __init__(
        self,
        bot_client: Any,
        user_client: Any,
        database: Database,
        state: RuntimeState,
        admin_id: int,
    ) -> None:
        self.bot_client = bot_client
        self.user_client = user_client
        self.database = database
        self.state = state
        self.admin_id = admin_id
        self._flows: dict[int, str] = {}

    def register(self) -> None:
        self.bot_client.add_event_handler(self.on_callback, events.CallbackQuery)
        self.bot_client.add_event_handler(
            self.on_message,
            events.NewMessage(incoming=True),
        )

    def unregister(self) -> None:
        self.bot_client.remove_event_handler(self.on_callback, events.CallbackQuery)
        self.bot_client.remove_event_handler(self.on_message, events.NewMessage)

    async def on_message(self, event: Any) -> None:
        if not getattr(event, "is_private", False):
            return
        sender_id = event.sender_id
        if sender_id != self.admin_id:
            await event.respond("❌ Accès refusé.")
            return

        text = (event.raw_text or "").strip()
        if text == "/start":
            self._flows.pop(sender_id, None)
            await self._respond_view(event, self._main_view())
            return
        if text == "/admin":
            self._flows.pop(sender_id, None)
            await self._respond_view(event, await self._admin_view())
            return

        flow = self._flows.pop(sender_id, None)
        if flow is None:
            return
        if flow == "source_add":
            await self._save_source(event, text)
        elif flow == "destination":
            await self._save_destination(event, text)
        elif flow == "keywords":
            await self._save_keywords(event, text)

    async def on_callback(self, event: Any) -> None:
        if not getattr(event, "is_private", False):
            await event.answer()
            return
        if event.sender_id != self.admin_id:
            await event.answer("Accès refusé.", alert=True)
            return

        action = event.data.decode("utf-8")
        await event.answer()
        if action == "main":
            await self._edit_view(event, self._main_view())
        elif action == "sources":
            await self._edit_view(event, self._sources_view())
        elif action == "source:add":
            self._flows[self.admin_id] = "source_add"
            await event.edit(
                "📥 AJOUTER UN CANAL SOURCE\n\n"
                "Envoie le @username ou l'identifiant du canal source.",
                buttons=[[Button.inline("🔙 ANNULER", b"sources")]],
            )
        elif action.startswith("source:remove:"):
            self.database.remove_source(int(action.rsplit(":", 1)[1]))
            await self._edit_view(event, self._sources_view())
        elif action == "destination":
            await self._edit_view(event, await self._destination_view())
        elif action == "destination:set":
            self._flows[self.admin_id] = "destination"
            await event.edit(
                "📤 CANAL DESTINATION\n\n"
                "Envoie le @username ou l'identifiant de ton canal destination.",
                buttons=[[Button.inline("🔙 ANNULER", b"destination")]],
            )
        elif action == "settings":
            await self._edit_view(event, self._settings_view())
        elif action.startswith("toggle:"):
            key = action.split(":", 1)[1]
            current = self.database.get_setting(key, "on") == "on"
            self.database.set_setting(key, "off" if current else "on")
            await self._edit_view(event, self._settings_view())
        elif action == "filters":
            await self._edit_view(event, self._filters_view())
        elif action.startswith("filter:"):
            content_type = action.split(":", 1)[1]
            current = enabled_content_types(self.database.get_setting)
            if content_type in current:
                current.remove(content_type)
            else:
                current.add(content_type)
            if not current:
                current = set(CONTENT_TYPES)
            self.database.set_setting("content_types", ",".join(sorted(current)))
            await self._edit_view(event, self._filters_view())
        elif action == "keywords":
            self._flows[self.admin_id] = "keywords"
            current = self.database.get_setting("keywords", "") or ""
            await event.edit(
                "🔎 MOTS-CLÉS\n\n"
                "Envoie des mots-clés séparés par des virgules. "
                "Laisse vide pour désactiver le filtre.\n\n"
                f"Actuels : {current or 'désactivés'}",
                buttons=[[Button.inline("🔙 RETOUR", b"settings")]],
            )
        elif action == "stats":
            await self._edit_view(event, self._stats_view())
        elif action == "history":
            await self._edit_view(event, self._history_view())
        elif action == "admin":
            await self._edit_view(event, await self._admin_view())
        elif action == "admin:refresh":
            await self._edit_view(event, await self._admin_view(refresh=True))
        elif action.startswith("admin:toggle:"):
            chat_id = int(action.rsplit(":", 1)[1])
            channel = self.database.get_broadcast_channel(chat_id)
            if channel is not None:
                self.database.set_broadcast_channel_enabled(chat_id, not channel.enabled)
            await self._edit_view(event, await self._admin_view())
        elif action == "start":
            if not self.database.get_destination():
                await event.answer("Définis d'abord un canal destination.", alert=True)
            else:
                self.state.running = True
                await self._edit_view(event, self._main_view())
        elif action == "stop":
            self.state.running = False
            await self._edit_view(event, self._main_view())

    async def _save_source(self, event: Any, value: str) -> None:
        if not value:
            await event.respond("❌ Envoie un username ou un identifiant valide.")
            return
        try:
            entity = await self.user_client.get_entity(self._entity_input(value))
            chat_id = int(utils.get_peer_id(entity))
            username = getattr(entity, "username", None)
            title = getattr(entity, "title", None) or str(chat_id)
            self.database.add_source(chat_id, username, title)
            await event.respond("✅ Canal source ajouté.", buttons=self._back_buttons("sources"))
        except Exception:
            await event.respond(
                "🔴 Impossible d'accéder à ce canal avec le compte Telegram connecté. "
                "Vérifie que ce compte le voit.",
                buttons=self._back_buttons("sources"),
            )

    async def _save_destination(self, event: Any, value: str) -> None:
        if not value:
            await event.respond("❌ Envoie un username ou un identifiant valide.")
            return
        try:
            entity = await self.user_client.get_entity(self._entity_input(value))
            destination = getattr(entity, "username", None) or str(utils.get_peer_id(entity))
            self.database.set_setting("destination", destination)
            await event.respond(
                "✅ Canal destination enregistré.",
                buttons=self._back_buttons("destination"),
            )
        except Exception:
            await event.respond(
                "🔴 Impossible d'accéder à ce canal destination avec le compte connecté.",
                buttons=self._back_buttons("destination"),
            )

    async def _save_keywords(self, event: Any, value: str) -> None:
        normalized = ",".join(
            item.strip() for item in value.replace("\n", ",").split(",") if item.strip()
        )
        self.database.set_setting("keywords", normalized)
        await event.respond("✅ Mots-clés enregistrés.", buttons=self._back_buttons("settings"))

    def _main_view(self) -> tuple[str, list[list[Any]]]:
        stats = self.database.statistics()
        destination = self.database.get_destination() or "Non défini"
        status = "🟢 ACTIF" if self.state.running else "⏸️ ARRÊTÉ"
        text = (
            "🤖 REPUBLISHER BOT\n\n"
            f"📊 Statut : {status}\n"
            f"📥 Canaux sources : {len(self.database.list_sources())}\n"
            f"📤 Canal destination : {self._display_destination(destination)}\n"
            f"📨 Publications transférées : {stats['total']}"
        )
        buttons = [
            [Button.inline("📥 CANAUX SOURCES", b"sources")],
            [Button.inline("📤 CANAL DESTINATION", b"destination")],
            [Button.inline("👑 MODE ADMIN", b"admin")],
            [Button.inline("⚙️ PARAMÈTRES", b"settings")],
            [Button.inline("📊 STATISTIQUES", b"stats"), Button.inline("📝 HISTORIQUE", b"history")],
            [Button.inline("▶️ DÉMARRER", b"start"), Button.inline("⏸️ ARRÊTER", b"stop")],
        ]
        return text, buttons

    def _sources_view(self) -> tuple[str, list[list[Any]]]:
        sources = self.database.list_sources()
        lines = ["📥 CANAUX SOURCES", ""]
        buttons: list[list[Any]] = []
        if not sources:
            lines.append("Aucun canal configuré.")
        else:
            for index, source in enumerate(sources, start=1):
                label = source.username and f"@{source.username}" or source.title
                lines.append(f"{index}. {label} ✅")
                buttons.append(
                    [Button.inline(f"🗑️ Supprimer {label[:25]}", f"source:remove:{source.id}".encode())]
                )
        buttons.extend(
            [
                [Button.inline("➕ AJOUTER", b"source:add")],
                [Button.inline("🔙 RETOUR", b"main")],
            ]
        )
        return "\n".join(lines), buttons

    async def _destination_view(self) -> tuple[str, list[list[Any]]]:
        destination = self.database.get_destination()
        if not destination:
            status = "⚪ Non configurée"
        else:
            try:
                await self.user_client.get_entity(destination)
                status = "🟢 Accessible"
            except Exception:
                status = "🔴 Impossible d'y publier"
        text = (
            "📤 DESTINATION\n\n"
            f"Canal : {self._display_destination(destination or 'Non définie')}\n"
            f"Statut : {status}"
        )
        return text, [
            [Button.inline("✏️ MODIFIER", b"destination:set")],
            [Button.inline("🔙 RETOUR", b"main")],
        ]

    async def _admin_view(self, refresh: bool = False) -> tuple[str, list[list[Any]]]:
        known = {channel.chat_id: channel for channel in self.database.list_broadcast_channels()}

        if refresh or not known:
            for chat_id, username, title in await self._discover_admin_channels():
                self.database.add_broadcast_channel(chat_id, username, title)
            known = {channel.chat_id: channel for channel in self.database.list_broadcast_channels()}

        lines = [
            "👑 MODE ADMIN",
            "",
            "Diffuse automatiquement les publications sur les canaux où "
            "ton compte est administrateur, en plus de la destination "
            "principale. Coche/décoche pour activer ou désactiver un canal.",
            "",
        ]
        buttons: list[list[Any]] = []
        if not known:
            lines.append("Aucun canal administrateur détecté pour l'instant.")
        else:
            for channel in sorted(known.values(), key=lambda c: c.title.lower()):
                label = f"@{channel.username}" if channel.username else channel.title
                mark = "☑" if channel.enabled else "☐"
                buttons.append(
                    [
                        Button.inline(
                            f"{mark} {label[:35]}",
                            f"admin:toggle:{channel.chat_id}".encode(),
                        )
                    ]
                )
        buttons.extend(
            [
                [Button.inline("🔄 ACTUALISER LA LISTE", b"admin:refresh")],
                [Button.inline("🔙 RETOUR", b"main")],
            ]
        )
        return "\n".join(lines), buttons

    async def _discover_admin_channels(self) -> list[tuple[int, str | None, str]]:
        """Repère, via le compte connecté, les canaux où il est administrateur."""
        discovered: list[tuple[int, str | None, str]] = []
        async for dialog in self.user_client.iter_dialogs():
            entity = dialog.entity
            is_broadcast_or_group = getattr(entity, "broadcast", False) or getattr(
                entity, "megagroup", False
            )
            if not is_broadcast_or_group:
                continue
            try:
                permissions = await self.user_client.get_permissions(entity, "me")
            except Exception:
                continue
            if not getattr(permissions, "is_admin", False):
                continue
            chat_id = int(utils.get_peer_id(entity))
            username = getattr(entity, "username", None)
            title = getattr(entity, "title", None) or str(chat_id)
            discovered.append((chat_id, username, title))
        return discovered

    def _settings_view(self) -> tuple[str, list[list[Any]]]:
        cleaning = self.database.get_setting("cleaning", "on") == "on"
        add_destination = self.database.get_setting("add_destination", "on") == "on"
        return (
            "⚙️ PARAMÈTRES\n\n"
            f"🧹 Nettoyage : {'ON' if cleaning else 'OFF'}\n"
            f"➕ Ajouter mon @ : {'ON' if add_destination else 'OFF'}\n"
            f"🔎 Mots-clés : {self.database.get_setting('keywords') or 'désactivés'}",
            [
                [Button.inline(f"🧹 NETTOYAGE : {'ON' if cleaning else 'OFF'}", b"toggle:cleaning")],
                [
                    Button.inline(
                        f"➕ AJOUTER MON @ : {'ON' if add_destination else 'OFF'}",
                        b"toggle:add_destination",
                    )
                ],
                [Button.inline("⚙️ FILTRES DE CONTENU", b"filters")],
                [Button.inline("🔎 MOTS-CLÉS", b"keywords")],
                [Button.inline("🔙 RETOUR", b"main")],
            ],
        )

    def _filters_view(self) -> tuple[str, list[list[Any]]]:
        active = enabled_content_types(self.database.get_setting)
        buttons = [
            [
                Button.inline(
                    f"{'☑' if content_type in active else '☐'} {content_type.upper()}",
                    f"filter:{content_type}".encode(),
                )
            ]
            for content_type in CONTENT_TYPES
        ]
        buttons.append([Button.inline("🔙 RETOUR", b"settings")])
        return "⚙️ FILTRES\n\nSélectionne les types à republier.", buttons

    def _stats_view(self) -> tuple[str, list[list[Any]]]:
        stats = self.database.statistics()
        type_lines = "\n".join(
            f"{name.capitalize()} : {stats['types'].get(name, 0)}"
            for name in CONTENT_TYPES
        )
        return (
            "📊 STATISTIQUES\n\n"
            f"Publications traitées : {stats['total']}\n"
            f"{type_lines}\n"
            f"Erreurs : {stats['errors']}\n\n"
            f"Aujourd'hui : +{stats['today']} publications\n"
            f"Cette semaine : +{stats['week']} publications",
            [[Button.inline("🔙 RETOUR", b"main")]],
        )

    def _history_view(self) -> tuple[str, list[list[Any]]]:
        publications = self.database.recent_publications(10)
        if not publications:
            text = "📝 HISTORIQUE\n\nAucune publication traitée."
        else:
            lines = ["📝 HISTORIQUE", ""]
            for publication in publications:
                date = publication.date.astimezone(timezone.utc).strftime("%d/%m %H:%M")
                status = "✅" if publication.status == "success" else "🔴"
                lines.extend(
                    [
                        f"#{publication.id} {status}",
                        f"Source : {publication.source_name}",
                        f"Type : {publication.content_type.upper()}",
                        f"Date : {date}",
                        "",
                    ]
                )
            text = "\n".join(lines)
        return text, [[Button.inline("🔙 RETOUR", b"main")]]

    @staticmethod
    def _display_destination(destination: str) -> str:
        return destination if destination.startswith("@") or destination == "Non défini" else f"@{destination}"

    @staticmethod
    def _entity_input(value: str) -> str | int:
        normalized = value.strip()
        if re.fullmatch(r"-?\d+", normalized):
            return int(normalized)
        if normalized.startswith("@"):
            return normalized[1:]
        return normalized

    @staticmethod
    def _back_buttons(action: str) -> list[list[Any]]:
        return [[Button.inline("🔙 RETOUR", action.encode())]]

    @staticmethod
    async def _respond_view(event: Any, view: tuple[str, list[list[Any]]]) -> None:
        text, buttons = view
        await event.respond(text, buttons=buttons)

    @staticmethod
    async def _edit_view(event: Any, view: tuple[str, list[list[Any]]]) -> None:
        text, buttons = view
        try:
            await event.edit(text, buttons=buttons)
        except MessageNotModifiedError:
            return