"""Création des deux clients Telethon utilisés par l'application."""

from __future__ import annotations

from telethon import TelegramClient

from config.settings import Settings


def build_clients(settings: Settings) -> tuple[TelegramClient, TelegramClient]:
    user_client = TelegramClient(
        settings.session_path,
        settings.api_id,
        settings.api_hash,
    )
    bot_client = TelegramClient(
        f"{settings.session_path}_bot",
        settings.api_id,
        settings.api_hash,
    )
    return user_client, bot_client