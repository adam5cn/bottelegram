"""Branchement des événements de nouveaux messages et d'albums."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from telethon import events


@dataclass
class RuntimeState:
    running: bool = False


class Monitor:
    def __init__(self, user_client: Any, publisher: Any) -> None:
        self.user_client = user_client
        self.publisher = publisher

    def register(self) -> None:
        self.user_client.add_event_handler(
            self.publisher.handle_album,
            events.Album(),
        )
        self.user_client.add_event_handler(
            self.publisher.handle_new_message,
            events.NewMessage(incoming=True),
        )

    def unregister(self) -> None:
        self.user_client.remove_event_handler(
            self.publisher.handle_album,
            events.Album,
        )
        self.user_client.remove_event_handler(
            self.publisher.handle_new_message,
            events.NewMessage,
        )