# Telegram Republisher Bot

Bot Telegram professionnel de republication automatique de contenu. La
configuration des canaux, des filtres et du nettoyage se fait depuis Telegram.
La lecture des canaux est réalisée avec un compte Telegram connecté via
Telethon, et non avec le seul compte BotFather.

## Pré-requis

- Python 3.12 ou plus récent
- Un compte Telegram qui peut lire les canaux sources et publier dans le canal destination
- Une application Telegram créée sur https://my.telegram.org
- Un bot créé avec `@BotFather`

Le compte utilisateur Telethon doit être membre des sources privées. Le bot
créé avec BotFather doit être administrateur du canal dans lequel le panneau est
utilisé. Pour publier dans la destination, le compte Telethon doit aussi avoir
les droits nécessaires.

## Installation Windows

Ouvrez PowerShell dans le dossier `telegram_republisher` :

```powershell
python -m venv venv
venv\Scripts\activate
python -m pip install -r requirements.txt
Copy-Item .env.example .env
```

## Configuration

Ouvrez `.env` avec un éditeur de texte :

- `API_ID` : le numéro affiché par my.telegram.org dans votre application Telegram.
- `API_HASH` : le hash affiché au même endroit.
- `BOT_TOKEN` : le token donné par `@BotFather` après `/newbot`.
- `ADMIN_ID` : votre identifiant numérique Telegram. Vous pouvez l'obtenir
  auprès d'un bot fiable d'information Telegram, puis vérifier la valeur avant
  de l'utiliser.
- `AUTOSTART=true` démarre la surveillance automatiquement quand une
  destination est déjà enregistrée. Utilisez `false` pour démarrer seulement
  avec le bouton Telegram.

Ne publiez jamais `.env`, `data/` ou les fichiers de session. Ils sont déjà
exclus par `.gitignore`.

## Premier lancement

```powershell
venv\Scripts\activate
python main.py
```

Au premier lancement, Telethon demande dans la console le numéro du compte
utilisateur, le code reçu par Telegram et, si nécessaire, le mot de passe de
double authentification. Cette étape se fait uniquement dans la console, jamais
dans le panneau du bot. Une session locale est ensuite conservée dans `data/`.

Quand le programme affiche `Republisher démarré`, ouvrez la conversation avec
votre bot et envoyez `/start`.

## Utilisation dans Telegram

1. **Ajouter un canal source** : `/start` → `CANAUX SOURCES` → `AJOUTER`, puis
   envoyez son `@username` ou son identifiant. Répétez l'opération pour plusieurs
   sources.
2. **Définir la destination** : `/start` → `CANAL DESTINATION` → `MODIFIER`,
   puis envoyez son `@username` ou son identifiant.
3. **Configurer la republication** : `PARAMÈTRES` permet d'activer ou
   désactiver le nettoyage des mentions et liens Telegram, l'ajout automatique
   du `@username` destination, les types de contenu et les mots-clés.
4. **Démarrer** : utilisez `DÉMARRER`. Utilisez `ARRÊTER` pour mettre la
   surveillance en pause sans fermer le programme.
5. **Suivre l'activité** : `STATISTIQUES` affiche les compteurs et `HISTORIQUE`
   les dernières publications.

Le bot traite les textes, photos, vidéos, GIF, documents, fichiers, audios et
albums. Les médias sont téléchargés puis envoyés à nouveau afin d'éviter
l'en-tête « Transféré de ». Les messages traités sont enregistrés dans SQLite
avec le canal source, l'identifiant du message, l'album, la destination, le
statut et la date. Un même message ne peut donc pas être publié deux fois.

En cas d'erreur sur une source, l'erreur est enregistrée dans `logs/bot.log` et
les autres sources continuent d'être surveillées.

## Arrêt

Dans PowerShell, utilisez `Ctrl+C`. Pour supprimer une session utilisateur,
arrêtez le programme puis supprimez uniquement `data/user_session.session` et
relancez-le. Ne supprimez pas `data/republisher.sqlite3` sauf si vous voulez
perdre la configuration et l'historique.