# Telegram Republisher Bot

Projet Python autonome de republication automatique de contenu Telegram,
configurable depuis un panneau Telegram administrateur.

## Run & Operate

- `cd telegram_republisher`
- Windows : `python -m venv venv`
- Windows : `venv\Scripts\activate`
- `python -m pip install -r requirements.txt`
- `python main.py`
- Configuration : `telegram_republisher/.env`
- Logs : `telegram_republisher/logs/bot.log`
- Données : `telegram_republisher/data/republisher.sqlite3`

## Stack

- Python 3.12+
- Telethon pour le bot et le compte utilisateur de lecture
- SQLite créé automatiquement
- python-dotenv pour `.env`

## Where things live

- `telegram_republisher/main.py` : démarrage et orchestration
- `telegram_republisher/config/` : configuration d'environnement
- `telegram_republisher/database/` : schéma et accès SQLite
- `telegram_republisher/telegram/` : clients, panneau, surveillance et publication
- `telegram_republisher/filters/` : types de contenu et mots-clés
- `telegram_republisher/utils/` : nettoyage et logs

## Architecture decisions

- Un compte utilisateur Telethon lit les sources, car un bot BotFather ne peut
  pas lire arbitrairement les canaux privés.
- Le bot Telethon séparé sert de panneau de configuration administrateur.
- Les médias sont téléchargés puis renvoyés, au lieu d'utiliser un forward qui
  expose la source.
- SQLite conserve la configuration, l'anti-doublon, les statistiques et
  l'historique.

## Product

Le propriétaire peut gérer plusieurs sources, une destination, les types de
contenu, les mots-clés, le nettoyage des mentions et l'état de la surveillance
depuis Telegram.

## User preferences

- Projet destiné à un débutant, avec un guide Windows clair et sans
  configuration des canaux dans le code.

## Gotchas

- Les valeurs `API_ID`, `API_HASH`, `BOT_TOKEN` et `ADMIN_ID` sont nécessaires
  dans `telegram_republisher/.env`.
- La première connexion du compte utilisateur se fait dans la console et crée
  un fichier de session local à protéger.

## Pointers

- Le guide complet de lancement est dans `telegram_republisher/README.md`.
